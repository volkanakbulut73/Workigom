# 🎯 Workigom - Canlı Yayın Adım Adım Görsel Rehber

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│           🚀 WORKIGOM CANLI YAYIN ROADMap                       │
│                                                                 │
│   www.workigom.com domain'inizle canlı yayına alın!            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📋 GENEL BAKIŞ

```
┌──────────────┐
│  BAŞLANGIÇ   │
└──────┬───────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  ADIM 1: Domain Al                                       │
│  ⏱️  Süre: 5 dakika                                       │
│  💰 Maliyet: 50-150 TL/yıl                               │
│  📍 Natro.com / Namecheap.com                            │
└──────┬───────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  ADIM 2: Build Al                                        │
│  ⏱️  Süre: 2 dakika                                       │
│  💻 Komut: npm run build                                 │
│  📦 Sonuç: dist/ klasörü                                 │
└──────┬───────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  ADIM 3: Deploy Et                                       │
│  ⏱️  Süre: 1 dakika                                       │
│  🌐 Platform: Netlify.com (ücretsiz)                     │
│  🚀 Yöntem: Sürükle-bırak                                │
└──────┬───────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  ADIM 4: Domain Bağla                                    │
│  ⏱️  Süre: 2 dakika                                       │
│  🔗 Netlify'da custom domain ekle                        │
│  📝 DNS ayarları yap                                     │
└──────┬───────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  ADIM 5: DNS Bekle                                       │
│  ⏱️  Süre: 30-60 dakika                                   │
│  ☕ Kahve molası verin                                   │
│  🔍 dnschecker.org'da kontrol edin                       │
└──────┬───────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  ADIM 6: Supabase Kur                                    │
│  ⏱️  Süre: 3 dakika                                       │
│  🗄️  Database schema yükle                               │
│  👤 Test kullanıcıları oluştur                           │
└──────┬───────────────────────────────────────────────────┘
       │
       ▼
┌──────────────┐
│   ✅ CANLI   │
│              │
│ workigom.com │
└──────────────┘
```

---

## 🔍 ADIM 1: DOMAIN SATINA ALMA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  🌐 DOMAIN SEÇENEKLERİ                              │
│                                                     │
│  ┌─────────────────┬──────────┬─────────────────┐  │
│  │ Domain          │ Fiyat    │ Öneri           │  │
│  ├─────────────────┼──────────┼─────────────────┤  │
│  │ .com.tr         │ 50 TL    │ ⭐⭐⭐ EN UCUZ   │  │
│  │ .com            │ 150 TL   │ ⭐⭐⭐ PROFESYO.│  │
│  │ .app            │ 120 TL   │ ⭐⭐ MODERN     │  │
│  │ .io             │ 200 TL   │ ⭐ TECH        │  │
│  └─────────────────┴──────────┴─────────────────┘  │
│                                                     │
│  📍 ÖNERİLEN SAĞLAYICILAR:                          │
│     • Natro.com (Türkçe destek)                    │
│     • Namecheap.com (Ucuz)                         │
│     • GoDaddy.com (Popüler)                        │
│                                                     │
└─────────────────────────────────────────────────────┘

ADIMLAR:
1. Natro.com'a git
2. "workigom" ara
3. .com.tr seç (50 TL)
4. Hesap oluştur
5. Ödeme yap
✅ Domain hazır!
```

---

## 🔍 ADIM 2: BUILD ALMA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  💻 TERMINAL'DE ÇALIŞTIR                            │
│                                                     │
│  $ cd workigom                                      │
│  $ npm install        # 1 dakika                   │
│  $ npm run build      # 1 dakika                   │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │  ✅ Build başarılı!                         │   │
│  │  📦 dist/ klasörü oluşturuldu               │   │
│  │  📄 dist/index.html                         │   │
│  │  📂 dist/assets/                            │   │
│  │  📊 Boyut: ~2-5 MB                          │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
└─────────────────────────────────────────────────────┘

KONTROL:
$ ls dist/
✅ index.html var mı?
✅ assets/ klasörü var mı?
```

---

## 🔍 ADIM 3: NETLIFY'A DEPLOY

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  🌐 NETLIFY SÜRÜKLE-BIRAK DEPLOY                    │
│                                                     │
│  1. Tarayıcı aç                                     │
│     https://app.netlify.com/drop                   │
│                                                     │
│  2. Netlify'a ücretsiz kayıt ol                     │
│     (GitHub veya Email ile)                         │
│                                                     │
│  3. Dosya gezgininde dist/ klasörünü aç            │
│                                                     │
│  4. dist/ klasörünü tarayıcıya SÜRÜKLE              │
│     ┌─────────────────┐                             │
│     │  📂 dist/       │                             │
│     │  ───────►       │                             │
│     │  [Netlify]      │                             │
│     └─────────────────┘                             │
│                                                     │
│  5. ⏳ 30 saniye bekle                              │
│                                                     │
│  6. ✅ CANLI URL:                                   │
│     https://random-name-12345.netlify.app          │
│                                                     │
└─────────────────────────────────────────────────────┘

TEST:
Tıklayıp siteyi aç ✅
Login sayfası görünüyor mu? ✅
```

---

## 🔍 ADIM 4: CUSTOM DOMAIN BAĞLAMA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  🔗 NETLIFY'DA DOMAIN EKLEME                        │
│                                                     │
│  1. Netlify Dashboard                               │
│     └─ Sitenizi seçin                               │
│        └─ "Site settings" tıkla                     │
│           └─ "Domain management"                    │
│              └─ "Add custom domain"                 │
│                                                     │
│  2. Domain girin:                                   │
│     ┌─────────────────────────────────┐             │
│     │  workigom.com                   │ [Verify]    │
│     └─────────────────────────────────┘             │
│                                                     │
│  3. "Netlify DNS kullan" seçeneği seç               │
│                                                     │
│  4. 📝 Netlify 4 nameserver verecek:                │
│     • dns1.p03.nsone.net                            │
│     • dns2.p03.nsone.net                            │
│     • dns3.p03.nsone.net                            │
│     • dns4.p03.nsone.net                            │
│                                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│                                                     │
│  🌐 NATRO'DA DNS AYARLARI                           │
│                                                     │
│  1. Natro.com > Giriş yap                           │
│  2. Domain Yönetimi > workigom.com                  │
│  3. "Nameserver Ayarları"                           │
│  4. "Kendi nameserver kullan" seç                   │
│  5. Netlify'ın 4 nameserver'ını yapıştır:           │
│                                                     │
│     Nameserver 1: dns1.p03.nsone.net                │
│     Nameserver 2: dns2.p03.nsone.net                │
│     Nameserver 3: dns3.p03.nsone.net                │
│     Nameserver 4: dns4.p03.nsone.net                │
│                                                     │
│  6. "Kaydet" ✅                                      │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 🔍 ADIM 5: DNS YAYILMASI

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  ⏳ DNS PROPAGATION (30-60 Dakika)                  │
│                                                     │
│  DNS ayarları dünya geneline yayılıyor...          │
│                                                     │
│  ┌───────────────────────────────────────────┐     │
│  │                                           │     │
│  │   🌍 Dünya Haritası                       │     │
│  │                                           │     │
│  │   🟢 ABD     (Yayıldı)                    │     │
│  │   🟢 Avrupa  (Yayıldı)                    │     │
│  │   🟡 Asya    (Yayılıyor...)               │     │
│  │   🟢 Türkiye (Yayıldı)                    │     │
│  │                                           │     │
│  └───────────────────────────────────────────┘     │
│                                                     │
│  KONTROL:                                           │
│  https://dnschecker.org                            │
│  ┌─────────────────────────────────┐               │
│  │ Domain: workigom.com            │ [Check]       │
│  │ Type: A                         │               │
│  └─────────────────────────────────┘               │
│                                                     │
│  🟢 🟢 🟢 = Hazır!                                  │
│  🟡 🟢 🟡 = Bekle...                                │
│                                                     │
│  ☕ BU SIRADA:                                      │
│  • Kahve için                                       │
│  • Supabase kurulumuna başla                        │
│  • Dokümantasyonu oku                               │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 🔍 ADIM 6: SUPABASE KURULUMU

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  🗄️  SUPABASE DATABASE KURULUMU                     │
│                                                     │
│  1. Supabase Dashboard                              │
│     https://supabase.com/dashboard                 │
│                                                     │
│  2. Projenizi seçin                                 │
│                                                     │
│  3. SQL Editor > New query                          │
│                                                     │
│  4. Dosya aç:                                       │
│     supabase/migrations/001_initial_schema.sql     │
│                                                     │
│  5. SQL kodunu kopyala-yapıştır                     │
│                                                     │
│  6. "Run" ▶️ tıkla                                  │
│                                                     │
│  7. ✅ Success!                                     │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │  ✅ kv_store_018e1998 table oluşturuldu    │   │
│  │  ✅ users table oluşturuldu                │   │
│  │  ✅ İndeksler oluşturuldu                  │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│                                                     │
│  👤 TEST KULLANICILARI OLUŞTUR                      │
│                                                     │
│  HIZLI_BASLANGIC.md dosyasındaki SQL kodunu         │
│  çalıştırın (3 kullanıcı oluşturur):                │
│                                                     │
│  • individual@workigom.com / individual123          │
│  • corporate@workigom.com / corporate123            │
│  • admin@workigom.com / admin123                    │
│                                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│                                                     │
│  🔗 DOMAIN'İ SUPABASE'E EKLE                        │
│                                                     │
│  1. Authentication > URL Configuration              │
│  2. Site URL: https://www.workigom.com              │
│  3. Redirect URLs: https://www.workigom.com/*       │
│  4. Save                                            │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## ✅ TEST VE DOĞRULAMA

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│  🧪 SİTE ÇALIŞIYOR MU?                              │
│                                                     │
│  1. https://www.workigom.com aç                     │
│     ✅ Site açılıyor                                │
│     ✅ Workigom logosu görünüyor                    │
│     ✅ Login sayfası var                            │
│                                                     │
│  2. HTTPS kontrol                                   │
│     ✅ URL'de 🔒 kilit simgesi var                  │
│     ✅ "Güvenli" yazıyor                            │
│                                                     │
│  3. Login testi                                     │
│     Email: individual@workigom.com                  │
│     Şifre: individual123                            │
│     ✅ Giriş başarılı                               │
│     ✅ Ana sayfa açıldı                             │
│                                                     │
│  4. Mobil test                                      │
│     Telefonda aç: www.workigom.com                  │
│     ✅ Responsive görünüm                           │
│     ✅ Bottom navigation var                        │
│                                                     │
│  5. Performance test                                │
│     https://pagespeed.web.dev                      │
│     ✅ Score: 90+ (Hedef)                           │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 🎊 BAŞARILI! SİTENİZ CANLI

```
╔═════════════════════════════════════════════════════╗
║                                                     ║
║          🎉 TEBRİKLER! 🎉                           ║
║                                                     ║
║    Workigom artık canlı yayında!                    ║
║                                                     ║
║    🌐 https://www.workigom.com                      ║
║    🔒 HTTPS: Aktif                                  ║
║    📱 Mobil: Uyumlu                                 ║
║    🗄️  Database: Bağlı                              ║
║                                                     ║
║    PAYLAŞIN:                                        ║
║    🐦 Twitter                                       ║
║    📘 Facebook                                      ║
║    💼 LinkedIn                                      ║
║                                                     ║
╚═════════════════════════════════════════════════════╝
```

---

## 📊 ÖZET TABlo

| Adım | Süre | Maliyet | Durum |
|------|------|---------|-------|
| 1️⃣ Domain Al | 5 dk | 50-150 TL/yıl | ✅ |
| 2️⃣ Build | 2 dk | Ücretsiz | ✅ |
| 3️⃣ Deploy | 1 dk | Ücretsiz | ✅ |
| 4️⃣ Domain Bağla | 2 dk | Ücretsiz | ✅ |
| 5️⃣ DNS Bekle | 30-60 dk | Ücretsiz | ⏳ |
| 6️⃣ Supabase Kur | 3 dk | Ücretsiz | ✅ |
| **TOPLAM** | **~13 dk + DNS** | **50-150 TL/yıl** | **✅** |

---

## 🚀 SONRAKİ ADIMLAR

```
1. SEO Optimize Et
   └─ Meta tags
   └─ Sitemap
   └─ Google Search Console

2. Analytics Ekle
   └─ Google Analytics
   └─ Hotjar (kullanıcı davranışı)

3. Marketing
   └─ Sosyal medya paylaş
   └─ Google Ads (opsiyonel)
   └─ Email marketing

4. Geliştir
   └─ Yeni özellikler ekle
   └─ Kullanıcı geri bildirimleri
   └─ A/B testing
```

---

## 📚 YARDIMCI KAYNAKLAR

**Rehberler:**
- `HIZLI_CANLI_YAYIN.md` - 10 dakikada deployment
- `DOMAIN_VE_CANLI_YAYIN_REHBERI.md` - Detaylı domain rehberi
- `WEB_HOSTING_REHBERI.md` - Tüm hosting seçenekleri
- `HIZLI_BASLANGIC.md` - Supabase kurulumu
- `SORUN_GIDERME.md` - Hata çözümleri

**Script'ler:**
- `deploy.sh` (Linux/Mac)
- `deploy.bat` (Windows)

**Destek:**
- Netlify: https://answers.netlify.com
- Supabase: https://supabase.com/docs
- Domain: Natro/GoDaddy/Namecheap destek

---

**İyi çalışmalar! 🚀**

**Son Güncelleme:** 2 Kasım 2025
